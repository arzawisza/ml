while read line
do
    array[ $i ]="$line"
    (( i++ ))
done < <(ls -1 self.logs */)
for i in "${array[@]}"
do
   #grep -rn POST from  $i
   #.././scalp.py 
   echo "--> " + $i
   ./scalp.py -l lfi/$i -a dos --text
done