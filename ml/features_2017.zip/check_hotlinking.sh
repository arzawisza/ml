i=0
while read line
do
    array[ $i ]="$line"
    (( i++ ))
done < <(ls -1 links */)
for i in "${array[@]}"
do
   #grep -rn POST from  $i
   #.././scalp.py 
   echo "--> " + $i
   #./scalp.py -l xss/$i -a xss --text
awk -F\" '($2 ~ /\.(jpg|gif)/ && $4 !~ /^http:\/\/www\.secrepo\.com/){print $4}' links/$i \ | sort | uniq -c | sort
done