i=0
while read line
do
    array[ $i ]="$line"
    (( i++ ))
done < <(ls -d1 */)

for i in "${array[@]}"
do
   grep -rn POST from  self.logs/$i
done