# Copy this to config.py and modify its contents.

email_config = {
    'host': 'aaaasmtp.gmail.com',
    'port': '5870',
    'username': '',
    'password': '',
    'from': 'no-reply@localhost',
    'recipients': ['']
}
