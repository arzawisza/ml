i=0
while read line
do
    array[ $i ]="$line"
    (( i++ ))
done < <(ls -d1 self.logs/)

for i in "${array[@]}"
do
   grep -rn POST from  $i
   #.././scalp.py 
   #./scalp.py -l self.logs/$1 -a sqli -h
done